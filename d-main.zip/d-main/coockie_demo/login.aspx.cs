﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace coockie_demo
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btl_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Work\SEM-2\ASP.net-pjt\coockie_demo\coockie_demo\App_Data\coockie_demo.mdf;Integrated Security=True");
                con.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from [user] where username=@username and password=@password", con);
            cmd.Parameters.AddWithValue("@username", txtusername.Text.Trim().ToString());
            cmd.Parameters.AddWithValue("@password", txtpassword.Text.ToString());
            int i = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            if(i > 0)
            {
                Session["username"] = txtusername.Text;
                Response.Redirect("display.aspx");
            }
            else
            {
                Response.Write("<script>alert('username or password is invalid') </script>");
            }
        }
    }
}