﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnquirySystem
{
    public partial class Remove_Enquir : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["uname"] == null)
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\EnquiryDB.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string qry = "Delete From tblEnquiry where Enqid=@enqid";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@enqid", txtid.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Record Delete Successfully')</script>");
            txtid.Text = "";
        }
    }
}