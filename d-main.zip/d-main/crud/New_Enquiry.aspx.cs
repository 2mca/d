﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnquirySystem
{
    public partial class New_Enquir : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["uname"] == null)
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void btninsert_Click(object sender, EventArgs e)
        {
            string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\EnquiryDB.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string qry = "insert into tblEnquiry (Name,Email,BillNo,PhoneNo,Message) values (@name,@email,@billno,@phoneno,@message)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@name", txtname.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@billno", txtbillno.Text);
            cmd.Parameters.AddWithValue("@phoneno", txtphoneno.Text);
            cmd.Parameters.AddWithValue("@message", txtmessage.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Record Insert Successfully')</script>");
            txtname.Text = "";
            txtemail.Text = "";
            txtbillno.Text = "";
            txtphoneno.Text = "";
            txtmessage.Text = "";
        }
    }
}