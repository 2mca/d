﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EnquirySystem
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["uname"] = null;
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            try
            {
                string uname = txtusername.Text;
                string pass = txtpassword.Text;
                String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\EnquiryDB.mdf;Integrated Security=True";
                SqlConnection con = new SqlConnection(constr);
                con.Open();
                string qry = "select * from admin where username='" + uname + "' and password='" + pass + "'";
                SqlCommand cmd = new SqlCommand(qry, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Session["uname"] = dr.GetValue(1).ToString();
                    Response.Write("<script>alert('Login Successfully.....')</script>");
                    Response.Redirect("Viewall_Enquiry.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Login Failed.....')</script>");
                }
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}