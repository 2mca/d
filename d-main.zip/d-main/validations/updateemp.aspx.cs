﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_update_Click(object sender, EventArgs e)
    {
        String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\patel\Documents\HRM.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection con = new SqlConnection(constr);
        con.Open();

        string query = "update Employee set name=@name,email=@email,contactno=@contactno,offeredsalary=@offeredsalary where empid=@empid";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@empid", empid.Text);
        cmd.Parameters.AddWithValue("@name", name.Text);
        cmd.Parameters.AddWithValue("@email", email.Text);
        cmd.Parameters.AddWithValue("@contactno", contactno.Text);
        cmd.Parameters.AddWithValue("@offeredsalary", salary.Text);
        cmd.ExecuteNonQuery();

        con.Close();
        Response.Write("<script> alert('Employee Detail Updated Successfully'); </script>");
        empid.Text = "";
        name.Text = "";
        email.Text = "";
        contactno.Text = "";
        salary.Text = "";
    }
}