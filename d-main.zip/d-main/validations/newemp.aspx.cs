﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
    }

    protected void btn_insert_Click(object sender, EventArgs e)
    {
        String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\patel\Documents\HRM.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection con = new SqlConnection(constr);
        con.Open();

        string query = "Insert into Employee(name,email,contactno,offeredsalary)values(@name,@email,@contactno,@offeredsalary)";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@name",name.Text);
        cmd.Parameters.AddWithValue("@email", email.Text);
        cmd.Parameters.AddWithValue("@contactno", contactno.Text);
        cmd.Parameters.AddWithValue("@offeredsalary", salary.Text);
        cmd.ExecuteNonQuery();

        con.Close();
        Response.Write("<script> alert('Employee Detail Inserted Successfully'); </script>");
        name.Text = ""; 
        email.Text = ""; 
        contactno.Text = ""; 
        salary.Text = ""; 
    }
}